package com.virtusa.vtaf.Service;

import java.util.List;

import com.virtusa.vtaf.Model.Device;

public interface DeviceService {
	List<Device> listAll();
	
	public void save(Device device);
	
	public Device getById(Integer id);
	
	public boolean isExsist(Device device);
	
	public void delete(Integer id);

}
