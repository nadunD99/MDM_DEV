package com.virtusa.vtaf.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.vtaf.Model.Device;
import com.virtusa.vtaf.Service.DeviceService;

@RestController
public class DeviceController {

	private DeviceService deviceService;

	@Autowired
	public void setDeviceService(DeviceService deviceService) {
		this.deviceService = deviceService;
	}

	@GetMapping(path = "/devices", produces = "application/json")
	public ResponseEntity<List<Device>> listAllDevice() {
		List<Device> devices = deviceService.listAll();
		if (devices.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
			// You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<Device>>(devices, HttpStatus.OK);
	}

	@GetMapping(value = "/device/{id}", produces = "application/json")
	public ResponseEntity<?> getDevice(@PathVariable("id") Integer id) {

		Device device = deviceService.getById(id);
		if (device == null) {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Device>(device, HttpStatus.OK);
	}

	@PostMapping(value = "/device/save", consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveDevice(@RequestBody Device device) {
		
		

		if (deviceService.isExsist(device)) {
			return new ResponseEntity<>(
					"Unable to create. A device with same UUID " + device.getAlias() + " already exist.",
					HttpStatus.CONFLICT);
		}else {
				deviceService.save(device);
				return new ResponseEntity<Device>(device, HttpStatus.CREATED);
		}
	}

}
