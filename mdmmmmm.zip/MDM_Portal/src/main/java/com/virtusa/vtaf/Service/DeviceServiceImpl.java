package com.virtusa.vtaf.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.virtusa.vtaf.Model.Device;
import com.virtusa.vtaf.Repository.DeviceRepository;

@Service
public class DeviceServiceImpl implements DeviceService {

	@Autowired
	private DeviceRepository repo;

	public List<Device> listAll() {
		return repo.findAll();
	}

	public void save(Device device) {
		repo.save(device);
	}

	public Device getById(Integer id) {
		return repo.findById(id).get();
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public boolean isExsist(Device device) {
		List<Device>  dList=  repo.findAll(); 
		boolean exsist= dList.contains(device.getUuid());
		return exsist;
	}
}
