package com.virtusa.vtaf.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.vtaf.Model.Device;

public interface DeviceRepository extends JpaRepository<Device, Integer>{

}
