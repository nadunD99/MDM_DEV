package com.virtusa.vtaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdmPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdmPortalApplication.class, args);
	}

}
